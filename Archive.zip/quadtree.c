/* dictionary.c
*
* Created by Supakorn Sumongkol (ssumongkol@student.unimelb.edu.au) 15/08/2022
*
* contain data structure 'linkedListNode' and functions logic 
* related to 'linkedListNode'.
* 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <float.h>
#include "quadtree.h"
#include "data.h"

// struct quadtree {
//     quadTreeNode_t *root_node;
//     int height;
// };

struct quadtreeNode {
    rectangle2D_t *rec;
    quadTreeNode_t *SW;
    quadTreeNode_t *NW;
    quadTreeNode_t *NE;
    quadTreeNode_t *SE;
    int is_leafnode;
};

struct rectangle2D {
    point2D_t *bl_point;
    point2D_t *tr_point;
    datapoint_t *datapoint;
};

struct datapoint {
    point2D_t *loc;
    data_t *data;
};

struct point2D {
    long double x;
    long double y;
};

enum Quadrant{SW, NW, NE, SE};


point2D_t *point2DCreate() {
    point2D_t *point = (point2D_t *) malloc(sizeof(*point)); 
    assert(point);
    return point;
}

datapoint_t *datapointCreate() {
    datapoint_t *point = (datapoint_t *) malloc(sizeof(*point)); 
    assert(point);
    point->loc = point2DCreate();
    return point;
}

rectangle2D_t *rectangle2DCreate() {
    rectangle2D_t *rec = (rectangle2D_t *) malloc(sizeof(*rec)); 
    assert(rec);
    rec->datapoint = NULL;
    rec->bl_point = point2DCreate();
    rec->tr_point = point2DCreate();
    return rec;
}

quadtreeNode_t *quadtreeNodeCreate() {
    quadtreeNode_t *node = (quadtreeNode_t *) malloc(sizeof(*node)); 
    assert(node);
    node->rec = rectangle2DCreate();
    node->is_leafnode = 1
    node->SW = NULL;
    node->NW = NULL;
    node->NE = NULL;
    node->SE = NULL;
    return node;
}

// quadtree_t *quadtreeCreate() {
//     quadtree_t *point = (point2D_t *) malloc(sizeof(*point)); 
//     assert(point);
//     return point;
// }

void assignPoint2D(long double x, long double y, point2D_t *point) {
    point->x = x;
    point->y = y;
}

void assignDatapoint(point2D_t *point2D, data_t *d, datapoint_t *datapoint) {
    datapoint->loc = point2D;
    datapoint->data = d;
}

void assignRectangle2D(point2D_t *bl, point2D_t *tr, datapoint_t *datapoint,
rectangle2D_t *rec) {
    rec->datapoint = datapoint;
    rec->bl_point = bl;
    rec->tr_point = tr;
}

void assignRectangle2DPoint(int is_bl, long double *x, long double *y, 
rectangle2D_t *rec) {
    if (is_bl == 1) {
        rec->bl_point->x = x;
        rec->bl_point->y = y;
    } else if (is_bl == 0) {
        rec->tr_point->x = x;
        rec->tr_point->y = y;
    }
}

void assignQuadtreeNode(rectangle2D_t *rec, quadtreeNode_t *node) {
    node->rec = rec;
} 

void subDivideNode(quadtreeNode_t *node) {
    int new_data_quadrant;
    quadtreeNode_t *node_SW, *node_NW, *node_NE, *node_SE;
    node_SW = node_NW = node_NE = node_SE = quadtreeNodeCreate();
    node_SW->rec->bl_point = node->rec->bl_point;
    node_SW->rec->tr_point->x = (node->rec->bl_point->x + node->rec->tr_point->x) / 2;
    node_SW->rec->tr_point->y = (node->rec->bl_point->y + node->rec->tr_point->y) / 2;

    node_NW->rec->bl_point->x = node->rec->bl_point->x;
    node_NW->rec->bl_point->y = node_SW->rec->tr_point->y;
    node_NW->rec->tr_point->x = node_SW->rec->tr_point->x;
    node_NW->rec->tr_point->y = node->rec->tr_point->y;

    node_NE->rec->bl_point = node_SW->rec->tr_point;
    node_NE->rec->tr_point = node->rec->tr_point;

    node_SE->rec->bl_point->x = node_SW->rec->tr_point->x;
    node_SE->rec->bl_point->y = node->rec->bl_point->y;
    node_SE->rec->tr_point->x = node->rec->tr_point->x;
    node_SE->rec->tr_point->y = node_SW->rec->tr_point->y;

    node->SW = node_SW;
    node->NW = node_NW;
    node->NE = node_NE;
    node->SE = node_SE;
    node->is_leafnode = 0;

    assignDataQuadrant(node->rec->datapoint, node);
    node->rec->datapoint = NULL;
}

void addPoint(datapoint_t *datapoint, quadtreeNode_t *node) {
    if (node->is_leafnode) {
        if (node->rec->datapoint != NULL) {
            subDivideNode(node);
            addPoint(datapoint, node);
        } else {
            node->rec->datapoint = datapoint;
        }
    } else {
        int new_data_quadrant = determineQuadrant(datapoint->loc, node->rec);
        switch (new_data_quadrant) {
            case 0:
                addPoint(datapoint, node->SW);
                break;
            case 1:
                addPoint(datapoint, node->NW);
                break;
            case 2:
                addPoint(datapoint, node->NE);
                break;
            case 3:
                addPoint(datapoint, node->SE);
                break;
        }
    }
}

void assignDataToQuadtree(data_t *d, quadtreeNode_t *root_node) {
    datapoint_t *new_datapoint1 = *new_datapoint2 = datapointCreate();
    new_datapoint1->data = new_datapoint2->data = d;
    new_datapoint1->loc->x = dataGetStartLon(d);
    new_datapoint1->loc->y = dataGetStartLat(d);
    new_datapoint2->loc->x = dataGetEndLon(d);
    new_datapoint2->loc->y = dataGetEndLat(d);
    addPoint(new_datapoint1, root_node);
    addPoint(new_datapoint2, root_node);
}

// not sure
int inRectangle(point2D_t *point2D, rectangle2D_t *rectangle) {
    if (point2D->x >= rectangle->bottomleft_point->x 
    && point2D->x <= rectangle->topright_point->x
    && point2D->y >= rectangle->bottomleft_point->y 
    && point2D->y <= rectangle->topright_point->y) {
        return 1;
    }
    return 0;
}

// not sure
int rectangleOverlap(rectangle2D_t *a, rectangle2D_t *b) {
    if (inRectangle(a->bottomleft_point, b)
    || inRectangle(a->topright_point, b)
    || inRectangle(b->bottomleft_point, a)
    || inRectangle(b->topright_point, a)) {
        return 1;
    }
    return 0;
}

int determineQuadrant(point2D_t *p, rectangle2D_t *rec) {
    if (inRectangle(p, rec)) {
        if (p->x >= (rec->bl_point->x + rec->tr_point->x)/2.0) {
            if (p->y >= (rec->bl_point->y + rec->tr_point->y)/2.0) {
                return 2;
            } else {
                return 3;
            }
        } else {
            if (p->y >= (rec->bl_point->y + rec->tr_point->y)/2.0) {
                return 1;
            } else {
                return 0;
            }
        }
    }
    return -1;
}









void searchDatapoint(double search_lon, double search_lat,
quadtreeNode_t *root_node, FILE *out_file) {
    quadtreeNode_t *final_search_quadrant;
    point2D_t *search_point = point2DCreate();
    search_point->x = search_lon;
    search_point->y = search_lat;
    if (inRectangle(search_point, root_node->rec)) {
        final_search_quadrant = accessQuadrant(search_point, root_node);
        if (comparePoint2D(search_point, final_search_quadrant->rec->datapoint->loc)) {
            dataPrintFinal(out_file, final_search_quadrant->rec->datapoint->data);
            printf("\n");
        } else {
            printf("NOTFOUND\n");
        }
    } else {
        printf("NOTFOUND\n");
    }
}

quadtreeNode_t *accessQuadrant(point2D_t *search_point, quadtreeNode_t *node) {
    if (node->is_leafnode) {
        return node;
    } else {
        int quadrant_to_access = determineQuadrant(search_point, node->rec);
        switch (quadrant_to_access) {
            case 0:
                printQuadrantText(quadrant_to_access);
                accessQuadrant(search_point, node->SW);
                break;
            case 1:
                printQuadrantText(quadrant_to_access);
                accessQuadrant(search_point, node->NW);
                break;
            case 2:
                printQuadrantText(quadrant_to_access);
                accessQuadrant(search_point, node->NE);
                break;
            case 3:
                printQuadrantText(quadrant_to_access);
                accessQuadrant(search_point, node->SE);
                break;
        }
    }
}

void printQuadrantText(enum Quadrant q) {
    switch (q) {
        case SW:
            printf(" SW");
        case NW:
            printf(" NW");
        case NE:
            printf(" NE");
        case SE:
            printf(" SE");
    }
}

int comparePoint2D(point2D_t *a, point2D_t *b) {
    if (fabEquals(a->x, b->x) && fabEquals(a->y, b->y)) {
        return 1;
    }
    return 0;
}

int fabEquals(double a, double b) {
    if (fabs(a-b) < DBL_EPSILON) {
        return 1;
    }
    return 0;
}

void rangeQuery(rectangle2D_t rec) {
    if (rec->SW != NULL) {
        rangeQuery(rec->SW->rectangle);
    }
    if (rec->NW != NULL) {
        rangeQuery(rec->NW->rectangle);
    }
    if (rec->NE != NULL) {
        rangeQuery(rec->NE->rectangle);
    }
    if (rec->SE != NULL) {
        rangeQuery(rec->SE->rectangle);
    }
    //print datapoint
}


// void inOrderTransveral() {

// }














/* creates & returns an empty node
* (inspired from arrayCreate(...) in W3.8 skeleton code)
*/
linkedListNode_t *nodeCreate() {
	linkedListNode_t *node = malloc(sizeof(*node));
	assert(node);
	node->data = NULL;
	node->next = NULL;
	return node;
}

/* assign data_t element into node(linkedListNode)
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
void assignDataToNode(linkedListNode_t *node, data_t *d) {
	node->data = d;
}

/* assign pointer to the next node(linkedListNode) into node
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
void assignNextToNode(linkedListNode_t *current_node, 
linkedListNode_t *nextNode) {
	current_node->next = nextNode;
}

/* get node->data value
* return (data_t) node->data
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
data_t *getDataInNode(linkedListNode_t *node) {
	return node->data;
}

/* get node->next value
* return (linkedListNode_t) node->next
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
linkedListNode_t *getNextNode(linkedListNode_t *node) {
	return node->next;
}

/* get node->data->address value
* return (char *) node->data->address
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
char *getAddressInNode(linkedListNode_t *node) {
	return dataGetAddress(node->data);
}

/* get node->data->grade1in value
* return (dobule) node->data->grade1in
* (inspired from studentGetID(...) in W3.8 skeleton code)
*/
double getGrade1inInNode(linkedListNode_t *node) {
	return dataGetGrade1in(node->data);
}

// validate whether node->next is NULL or not?
int validateNextNode(linkedListNode_t *node) {
	if (node->next != NULL) {
		return 1;
	} else {
		return 0;
	}
}

/* print data in node to output_file(.txt) starting from the 1st to last node
* for debugging purpose only
* (inspired from arrayPrint(...) in W3.8 skeleton code)
*/
void dictionaryPrint(FILE *out_file, linkedListNode_t *head_node) {
	linkedListNode_t *current_node = head_node;

	while (current_node->next != NULL) {
		dataPrint(out_file, current_node->data);
		current_node = current_node->next;
	}
	dataPrint(out_file, current_node->data);
}

/* free memory used by linkedListNode_t "node" from 1st to last node
* (inspired from arrayFree(...) in W3.8 skeleton code)
*/
void dictionaryFree(linkedListNode_t *head_node) {
	linkedListNode_t *current_node, *prev_node;
	current_node = head_node;

	while (current_node != NULL) {
		dataFree(current_node->data);
		prev_node = current_node;
		current_node = current_node->next;
		free(prev_node);
	}
}
